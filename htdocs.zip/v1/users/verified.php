<?php

if ($_SERVER['REQUEST_METHOD'] == "GET") {
    $userId = '447449877';
    echo json_encode(true);}